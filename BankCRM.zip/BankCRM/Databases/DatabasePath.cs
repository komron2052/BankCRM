﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCRM.Databases
{
    internal class DatabasePath
    {
        public const string Bank_User_Info_Path = "C:\\Bootcamp\\C#\\BankCRM\\Databases\\BankBase.txt";
    }
}
