﻿using BankCRM.BankRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCRM.IUserInterface
{
    internal interface UserInterface
    {
        void Create(BankManagement BM);
        void Delete(string name);
        BankManagement Get(string name);
        List<BankManagement> GetAll();
        void Update(string name, BankManagement BM);
        int Calculate(int Sum, int Month);
    }
}
