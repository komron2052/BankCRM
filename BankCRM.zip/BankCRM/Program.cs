﻿using System;
namespace BankCRM
{
    internal class Bank
    {
        internal static void Main(string[] args)
        {

        }
    }
}