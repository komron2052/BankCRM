﻿using BankCRM.Databases;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCRM.BankRepository
{
    internal class BankService : BankManagement
    {
        private readonly string path = DatabasePath.Bank_User_Info_Path;
        public void Create(BankManagement BM)
        {
            if (BM.Id != null && BM.FirstName is not null && BM.FirstName != string.Empty &&
            BM.FirstName is not null && BM.LastName != string.Empty && BM.Birthday != null && BM.Sum != null && BM.Month != null)
            {
                var Saver = $"{BM.Id}|{BM.FirstName}|{BM.LastName}|{BM.Birthday}|{BM.Sum}|{BM.Month}|{BM.Calculalate}\n";
                File.AppendAllText(path, Saver);
            }
            else
            {
                Console.WriteLine("You entered wrong data");
            }
        }
        public void Delete(string name)
        {
            var UserInfo = GetAll();
            File.WriteAllText(path, "");
            foreach(var element in UserInfo)
            {
                if(element.FirstName == name)
                {
                    continue;
                }
                Create(element);
            }
        }
        

        public BankManagement Get(string name)
        {
            var UserInfo = GetAll();
            foreach (var element in UserInfo)
            {
                if (element.FirstName == name)
                {
                    return GetAll().FirstOrDefault(d => d.FirstName.ToLower().Equals(name.ToLower()));
                }
            }
            return GetAll().FirstOrDefault(d => d.FirstName.ToLower().Equals(name.ToLower()));
        }
        public List<BankManagement> GetAll()
        {
            string[] infom = File.ReadAllText(path).Split('\n');
            List<BankManagement> BankList = new List<BankManagement>();
            foreach(string info in infom)
            {
                if(info != string.Empty || info != null)
                {
                    string[] pieces = info.Split('|');
                    BankManagement bankManagement = new BankManagement();
                    {
                        Id = int.Parse(pieces[0]);
                        FirstName = pieces[1];
                        LastName = pieces[2];
                        Birthday = DateTime.Parse(pieces[3]);
                        Sum = int.Parse(pieces[4]);
                        Month = int.Parse(pieces[5]);
                    };
                    BankList.Add(bankManagement);
                }
            }
            return BankList;
        }
        public void Update(string name, BankManagement BM)
        {
            var info = GetAll();
            File.WriteAllText(path, "");
            foreach(var inf in info){
                if(BM.FirstName == name)
                {
                    inf.FirstName = BM.FirstName;
                    inf.LastName = BM.LastName;
                    inf.Birthday = BM.Birthday;
                }
                Create(inf);
            }
        }
        
    }
}
