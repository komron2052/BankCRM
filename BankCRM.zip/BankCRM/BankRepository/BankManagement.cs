﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankCRM.BankRepository
{
    internal class BankManagement
    {
        

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime Birthday { get; set; }
        public int Sum { get; set; }
        public int Month { get; set; }

        public BankManagement(int id, string firstName, string lastName, DateTime birthday, int sum, int month) {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Birthday = birthday;
            Sum = sum;
            Month = month;
        }
        public BankManagement() { }
        public int Calculalate(int Sum, int Month)
        {
            if (Sum > 100000)
            {
                return (int)((Sum / 100) * (1.5 * Month) + Sum);
            }
            else
            {
                return Sum;
            }
        }
    }
}
